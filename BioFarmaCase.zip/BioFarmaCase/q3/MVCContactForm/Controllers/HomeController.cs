﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

public class HomeController : Controller
{
    private static List<ContactModel> contacts = new List<ContactModel>();

    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Contact()
    {
        if (contacts == null)
        {
            contacts = new List<ContactModel>();
        }

        return View();
    }

    [HttpPost]
    public IActionResult Contact(ContactModel model)
    {
        if (ModelState.IsValid)
        {
            // Store the contact info in memory
            contacts.Add(model);

            // Return a success message
            ViewBag.Message = "Form submitted successfully!";
        }

        return View(model);
    }
}
