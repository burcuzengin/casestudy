using System;

public class ContactModel
{
    public string Name { get; set; }
    public DateTime DateOfBirth { get; set; }
    public int Age { get; set; }
    public string City { get; set; }
}
