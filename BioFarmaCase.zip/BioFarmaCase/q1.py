from collections import defaultdict

points = [(1,2), (3,7), (0,6), (1,1), (-5,2), (1,5), (3,-5)]

lines = defaultdict(list)

for i in range(len(points)-1):
    x1, y1 = points[i]
    
    for j in range(i+1, len(points)):
        x2, y2 = points[j]
        
        if x1 == x2:
            slope = float('inf')
            yIntercept = x1     #x1 as y-intercept for vertical lines
        else:
            slope = (y2 - y1) / (x2 - x1)
            yIntercept = y1 - slope * x1
        
        lines[(slope, yIntercept)].append((x1, y1))
        lines[(slope, yIntercept)].append((x2, y2))

yParallelCount = 0
xParallelCount = 0

for linePoints in lines.values():
    uniquePoints = set(linePoints)
    
    if len(uniquePoints) == 1:
        # Only one distinct point exists on the line
        continue
    
    xValues = {x for x, _ in uniquePoints}
    yValues = {y for _, y in uniquePoints}
    
    if len(xValues) == 1:
        xParallelCount += 1
    elif len(yValues) == 1:
        yParallelCount += 1

print("Number of lines parallel to the y-axis:", yParallelCount)
print("Number of lines parallel to the x-axis:", xParallelCount)
