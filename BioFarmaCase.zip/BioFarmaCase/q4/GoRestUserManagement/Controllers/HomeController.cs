﻿using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GoRestUserManagement.Models;
using System.Text.Json.Serialization;
using System.Text.Json;

public class HomeController : Controller
{
    private readonly HttpClient _httpClient;

    public HomeController(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<IActionResult> Users()
    {
        var response = await _httpClient.GetAsync("https://gorest.co.in/public/v2/users");
        response.EnsureSuccessStatusCode();

        var jsonString = await response.Content.ReadAsStringAsync();
        var usersResponse = JsonSerializer.Deserialize<User[]>(jsonString, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        });

       return View("Users", usersResponse.ToList());

    }
    
    public IActionResult Index()
    {
        return RedirectToAction("Users");
    }


}
