﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

class HesCodeResult
{
    public string Hes { get; set; }
    public string Status { get; set; }
}

class Program
{
    static async Task Main()
    {
        List<string> hesCodes = new List<string>
        {
            "G1B5-6449-15",
            "G5B2-3442-88"
        };

        List<HesCodeResult> results = new List<HesCodeResult>();

        foreach (var hesCode in hesCodes)
        {
            dynamic result = await VerifyHesCode(hesCode);
            results.Add(new HesCodeResult { Hes = hesCode, Status = result.status });
        }

        List<HesCodeResult> riskyHesCodes = results.FindAll(r => r.Status == "risky");
        List<HesCodeResult> risklessHesCodes = results.FindAll(r => r.Status == "riskless");

        Console.WriteLine("Risky HES Codes:");
        foreach (var code in riskyHesCodes)
        {
            Console.WriteLine($"HES: {code.Hes}, Status: {code.Status}");
        }

        Console.WriteLine("\nRiskless HES Codes:");
        foreach (var code in risklessHesCodes)
        {
            Console.WriteLine($"HES: {code.Hes}, Status: {code.Status}");
        }
    }

    static async Task<dynamic> VerifyHesCode(string hesCode)
    {
        using (var client = new HttpClient())
        {
            var url = "https://api.saglikbakanligi.gov.tr/HES/dogrula";
            var requestData = new { hes = hesCode };
            var response = await client.PostAsJsonAsync(url, requestData);
            response.EnsureSuccessStatusCode();
            var responseContent = await response.Content.ReadAsStringAsync();
            return System.Text.Json.JsonSerializer.Deserialize<dynamic>(responseContent);
        }
    }
}
